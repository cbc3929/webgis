create function st_length(text) returns double precision
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT ST_Length($1::public.geometry);
$$;

alter function st_length(text) owner to postgres;

