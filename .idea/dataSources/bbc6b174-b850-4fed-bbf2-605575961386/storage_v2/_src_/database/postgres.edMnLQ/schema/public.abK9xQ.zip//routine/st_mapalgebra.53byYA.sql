create function st_mapalgebra(rast1 raster, rast2 raster, expression text, pixeltype text DEFAULT NULL::text, extenttype text DEFAULT 'INTERSECTION'::text, nodata1expr text DEFAULT NULL::text, nodata2expr text DEFAULT NULL::text, nodatanodataval double precision DEFAULT NULL::double precision) returns raster
    immutable
    parallel safe
    language sql
as
$$
SELECT public.ST_mapalgebra($1, 1, $2, 1, $3, $4, $5, $6, $7, $8)
$$;

alter function st_mapalgebra(raster, raster, text, text, text, text, text, double precision) owner to postgres;

