create function st_containsproperly(rast1 raster, rast2 raster) returns boolean
    immutable
    parallel safe
    cost 1000
    language sql
as
$$
SELECT public.st_containsproperly($1, NULL::integer, $2, NULL::integer)
$$;

comment on function st_containsproperly(raster, raster) is 'args: rastA, rastB - Return true if rastB intersects the interior of rastA but not the boundary or exterior of rastA.';

alter function st_containsproperly(raster, raster) owner to postgres;

