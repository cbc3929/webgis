create function st_3dintersects(geom1 geometry, geom2 geometry) returns boolean
    immutable
    parallel safe
    language sql
as
$$
SELECT $1 OPERATOR(public.&&) $2 AND public._ST_3DIntersects($1, $2)
$$;

comment on function st_3dintersects(geometry, geometry) is 'args: geomA, geomB - Returns TRUE if the Geometries "spatially intersect" in 3d - only for points, linestrings, polygons, polyhedral surface (area). With SFCGAL backend enabled also supports TINS';

alter function st_3dintersects(geometry, geometry) owner to postgres;

