create function st_pointfromtext(text, integer) returns geometry
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT CASE WHEN public.geometrytype(public.ST_GeomFromText($1, $2)) = 'POINT'
	THEN public.ST_GeomFromText($1, $2)
	ELSE NULL END

$$;

comment on function st_pointfromtext(text, integer) is 'args: WKT, srid - Makes a point Geometry from WKT with the given SRID. If SRID is not given, it defaults to unknown.';

alter function st_pointfromtext(text, integer) owner to postgres;

