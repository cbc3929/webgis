create function addoverviewconstraints(ovtable name, ovcolumn name, reftable name, refcolumn name, ovfactor integer) returns boolean
    strict
    language sql
as
$$
SELECT  public.AddOverviewConstraints('', $1, $2, '', $3, $4, $5)
$$;

comment on function addoverviewconstraints(name, name, name, name, integer) is 'args: ovtable, ovcolumn, reftable, refcolumn, ovfactor - Tag a raster column as being an overview of another.';

alter function addoverviewconstraints(name, name, name, name, integer) owner to postgres;

