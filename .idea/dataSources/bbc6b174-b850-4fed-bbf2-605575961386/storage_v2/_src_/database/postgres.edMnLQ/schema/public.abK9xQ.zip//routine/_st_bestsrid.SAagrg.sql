create function _st_bestsrid(geography) returns integer
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT public._ST_BestSRID($1,$1)
$$;

alter function _st_bestsrid(geography) owner to postgres;

