create function raster_right(raster, raster) returns boolean
    immutable
    strict
    parallel safe
    language sql
as
$$
select $1::geometry >> $2::geometry
$$;

alter function raster_right(raster, raster) owner to postgres;

