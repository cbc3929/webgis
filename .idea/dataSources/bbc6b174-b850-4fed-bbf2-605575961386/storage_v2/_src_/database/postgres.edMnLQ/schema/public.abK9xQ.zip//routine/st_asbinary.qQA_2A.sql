create function st_asbinary(raster, outasin boolean DEFAULT false) returns bytea
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT public.ST_AsWKB($1, $2)
$$;

comment on function st_asbinary(raster, boolean) is 'args: rast, outasin=FALSE - Return the Well-Known Binary (WKB) representation of the raster.';

alter function st_asbinary(raster, boolean) owner to postgres;

